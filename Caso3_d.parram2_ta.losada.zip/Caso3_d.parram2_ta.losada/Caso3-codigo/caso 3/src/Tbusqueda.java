import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public class Tbusqueda implements Runnable {
    private List<String> cadenas;
    private String codigoHash;
    private String sal;
    private String algoritmo;
    private Tgenerador generador;

    public Tbusqueda(List<String> cadenas, String codigoHash, String sal, String algoritmo, Tgenerador generador) {
        this.cadenas = cadenas;
        this.codigoHash = codigoHash;
        this.sal = sal;
        this.algoritmo = algoritmo;
        this.generador = generador;
    }

    public Tbusqueda(String algoritmo2, String codigoHash2, String sal2, int numThreads) {
    }

    @Override
    public void run() {
        MessageDigest md;
        try {
            md = MessageDigest.getInstance(algoritmo);
        } catch (NoSuchAlgorithmException e) {
            System.err.println("Error: Algoritmo no soportado.");
            return;
        }

        for (String cadena : cadenas) {
            String concatenacion = generador.generarCadenaConcatenada(cadena, sal);
            byte[] hash = md.digest(concatenacion.getBytes());

            if (codigoHash.equals(Tgenerador.convertirHashAHexadecimal(hash))) {
                Treporte.reportarResultados(cadena, sal);
                return;
            }
        }
    }

    public void generarCadenas() {
    }

   

    public String getLista1() {
        return null;
    }

    public Object getAlgoritmo() {
        return null;
    }

    public Object getSal() {
        return null;
    }

    public Object getCodigoHash() {
        return null;
    }

    public int getNumThreads() {
        return 0;
    }

    public void dividirLista() {
    }

    public void buscar() {
    }


        
}
        
    
