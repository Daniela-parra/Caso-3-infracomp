public class Treporte {
    private Tgenerador generador;
    private int numThreads;

    public Treporte(Tgenerador generador, int numThreads) {
        this.generador = generador;
        this.numThreads = numThreads;
    }

    public static void reportarResultados(String cadena, String sal) {
        System.out.println("La contraseña es: " + cadena);
        System.out.println("La secuencia de sal es: " + sal);
    }

    public void mostrarResultados(long tiempoTotal) {
        System.out.println("Tiempo total de búsqueda: " + tiempoTotal + "ms");
        System.out.println("La contraseña no fue encontrada.");
    }
}
