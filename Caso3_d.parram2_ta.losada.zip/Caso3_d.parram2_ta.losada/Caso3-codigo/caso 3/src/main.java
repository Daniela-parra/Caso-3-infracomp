import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // Pedir los datos de entrada por consola
            System.out.print("Ingrese el algoritmo de generación de hash (SHA256 o SHA512): ");
            String algoritmo = scanner.nextLine();
            System.out.print("Ingrese el código criptográfico de hash de la contraseña: ");
            String codigoHash = scanner.nextLine();
            System.out.print("Ingrese la secuencia de sal: ");
            String sal = scanner.nextLine();
            System.out.print("Ingrese el número de threads (1 o 2): ");
            int numThreads = scanner.nextInt();

            // Crear objeto TBusqueda
            Tbusqueda tBusqueda = new Tbusqueda(algoritmo, codigoHash, sal, numThreads);

            // Generar lista de cadenas de longitud entre 1 y 7 caracteres
            tBusqueda.generarCadenas();

            // Dividir la lista en dos partes iguales si numThreads es 2
            tBusqueda.dividirLista();

            // Crear objetos TGenerador y TReporte
            Tgenerador tGenerador = new Tgenerador(tBusqueda.getLista1());
            Treporte tReporte = new Treporte(tGenerador, tBusqueda.getNumThreads());

            // Iniciar medición de tiempo
            long tiempoInicio = System.currentTimeMillis();

            // Realizar búsqueda
            tBusqueda.buscar();

            // Finalizar medición de tiempo
            long tiempoFin = System.currentTimeMillis();

            // Mostrar resultados
            tReporte.mostrarResultados(tiempoFin - tiempoInicio);
        }
    }
}
