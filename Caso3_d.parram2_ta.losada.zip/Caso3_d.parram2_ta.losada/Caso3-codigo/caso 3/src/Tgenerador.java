import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class Tgenerador {

    private String algoritmoHash;

    public Tgenerador(String algoritmoHash) {
        this.algoritmoHash = algoritmoHash;
    }

    public String generarCadenaConcatenada(String cadena2, String sal) {
        StringBuilder sb = new StringBuilder();
        sb.append(cadena2);
        sb.append(sal);
        return sb.toString();
    }

    public static String convertirHashAHexadecimal(byte[] hash) {
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    public byte[] generarHash(String cadenaConcatenada) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance(algoritmoHash);
        md.update(cadenaConcatenada.getBytes());
        return md.digest();
    }
}
